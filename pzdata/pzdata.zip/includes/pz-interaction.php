<?php

function pz_interaction_block($attributes) {
	global $wpdb;
	global $pz_cur_person;
    $pz_cur_interaction = 1;

	// wp_enqueue_script('aaa04', plugin_dir_url(__FILE__) . 'build/blocks/pz_person_edit/frontend.js', array('wp-element', 'wp-components'), null, true);
	
    ob_start();
    ?>
    <form class="form-style-1">
        <label>Summary</label>
        <input
            type="text"
            class="field-long"
            placeholder="Basic description of interaction..."
        />
        <label>Details</label>
        <textarea cols="85" rows="8"></textarea>
        <input type="submit" value="Save" />
    </form>
    <?php

    return ob_get_clean();
    

}
