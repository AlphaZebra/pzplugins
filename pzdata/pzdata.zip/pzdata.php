<?php
/**
 * Plugin Name:       Pzdata
 * Description:       Creates core tables for PeakZebra along with REST api.
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            Robert Richardson
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pzdata
 *
 * @package           pzdata
 */

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */


 define('PZ_PLUGIN_DIR', plugin_dir_path(__FILE__));


 // Includes

 include( PZ_PLUGIN_DIR . 'includes/register-blocks.php');
 include( PZ_PLUGIN_DIR . 'includes/pz-do-edit-block.php');
 include( PZ_PLUGIN_DIR . 'includes/pz-interaction.php');


 // Hooks


 add_action('init', 'pzx_register');

// add_action( 'init', 'create_block_pzdata_block_init' );

// function create_block_pzdata_block_init() {
// 	register_block_type( __DIR__ . '/build' , array(
// 		'render_callback' => 'pz_the_block'
// 	));
	
// }

function pz_person_block($attributes) {
	global $wpdb;
	global $pz_cur_person;

	// wp_enqueue_script('aaa04', plugin_dir_url(__FILE__) . 'build/blocks/pz_person_edit/frontend.js', array('wp-element', 'wp-components'), null, true);
	
	// if flag is set, we should read in and prefill the current person record
	$item = array(
		'id' => null,
		'firstname' => '',
		'lastname' => ''
	);
	
	// The isEdit attribute is true if an existing record should be read in for editing in the form. 
	// If true, the record with the id stored in the global $pz_cur_person is read in, even though
	// it's theoretically loaded in the $pz_cur_person array -- just a safety precaution in case the 
	// record has been changed elsewhere since the last time we read it in. 
	$update = '';
	if( $attributes['isEdit'] ) {
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pz_person WHERE id = {$pz_cur_person['id']}", ARRAY_A );
		$item = $results[0];
		$update = "update";
	} else if (isset($_GET['per'])) {
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pz_person WHERE id = {$_GET['per']}", ARRAY_A );
		$item = $results[0];
		$update = "update";
	}

	ob_start();
	?>
	
	<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" method="POST" class="form-style-1">
		<input type="hidden" name="action" value="do-person-edit-block" required>
		<input type="hidden" name="update" value="<?php echo $update;  ?>" required>
		<?php if( $update == "update" ) { ?>
		<input type="hidden" name="id" value="<?php echo $_GET['per'];  ?>" required>
		<?php } ?>
			<h3>Your basic information</h3>
			<!-- <label>ID</label>
			<input type="text" name="id" class="field-divided" value="<?php /*echo $item['id']*/ ?>" placeholder="9" />
			-->
			<label>Name</label>
			<input type="text" name="firstname" class="field-divided" value="<?php echo $item['firstname'] ?>" placeholder="First" />
			<input type="text" name="lastname" class="field-divided" value="<?php echo $item['lastname'] ?>" placeholder="Last" />
			<label>Title</label>
			<input type="text" name="title" class="field-long" placeholder="..." />
			<label>Company</label>
			<input type="text" name="company" class="field-long" placeholder="Your Company Name" />
			<label>Email</label>
			<input type="text" name="email" class="field-long" placeholder="you@yourcompany.com" />
			<input type="submit" value="Save" />
		</form>
	<div class="pz-target-div"><pre><?php /* echo wp_json_encode($attributes);*/ ?></pre></div>
	
	<?php
	return ob_get_clean();
}

$pz_cur_person = array(
    'id' => null,
    'firstname' => '',
    'lastname' => ''
  );

  function pz_person_list($attributes) {
	global $wpdb;
	global $pz_cur_person;

	// wp_enqueue_script('aaa04', plugin_dir_url(__FILE__) . 'build/blocks/pz_person_edit/frontend.js', array('wp-element', 'wp-components'), null, true);
	
	// if flag is set, we should read in and prefill the current person record
	$item = array(
		'id' => null,
		'firstname' => '',
		'lastname' => ''
	);
	
	if( isset($_GET['pzp'])) {
		$page = $_GET['pzp'];
	} else $page = 0;
	
	

	$limit = $attributes['numRows'];
	$offset = $limit * $page;
	
	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pz_person LIMIT $limit OFFSET $offset ", ARRAY_A );
	if( !isset($results[0])) {
		$offset=0;
		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pz_person LIMIT $limit OFFSET $offset ", ARRAY_A );
	};

	

	ob_start();
	?>
	<table class="pz-table-style" >
		
		<thead>
			<th>Edit</th>
			<th>ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Title</th>
			<th>Company</th>
			<th>Email</th>
			<th>Phone</th>
		</thead>

	<?php

	foreach($results as $result) {
		$title = ($result['title'] == '') ? "-" : $result['title'];
		echo '<tr><td><a href=' . $attributes['editURL'] . '?per=' .$result['id'] . '><image src=' . plugin_dir_url(__FILE__) . 'inc\pencil.png width="40%"></a></td><td>';
		echo $result['id'] . '</td><td>';
		echo $result['firstname'] . '</td><td>';
		echo $result['lastname'] . '</td><td>';
		echo $title . '</td><td>';
		echo $result['company'] . '</td><td>';
		echo $result['email'] . '</td><td>';
		echo $result['phone1'] . '</td></tr>';
		

	}
	?>

	<tr>
		<td><img src="<?php echo plugin_dir_url(__FILE__) ?>inc/left-arrow.png" width="80%"></td>
		<td></td>
		<td><img src="<?php echo plugin_dir_url(__FILE__) ?>inc/right-arrow.png" width="80%"></td>
	</tr>
	</table>
	<?php 

	return ob_get_clean();
}

